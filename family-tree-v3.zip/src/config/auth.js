// حساب المشرف.
// لا تُحفظ كلمة المرور هنا كنص، بل بصمتها SHA-256 فقط.
// لإنشاء البصمة في الطرفية:
//   printf '%s' 'كلمة-المرور-الجديدة' | sha256sum
// ثم ضع الناتج في ADMIN_PASSWORD_SHA256.
//
// تنبيه: هذا التحقق يتم داخل المتصفح، ويمنع قراءة كلمة المرور مباشرة فقط.
// الحماية الحقيقية تحتاج خادماً يتحقق من الجلسة.
export const ADMIN_USERNAME = "925495333";
export const ADMIN_PASSWORD_SHA256 = "";

const toHex = (buffer) =>
  [...new Uint8Array(buffer)].map((b) => b.toString(16).padStart(2, "0")).join("");

// يرجع { ok, reason } بدون أن يكشف أي قيمة سرية
export async function verifyAdmin(username, password) {
  if (!ADMIN_PASSWORD_SHA256) return { ok: false, reason: "not-configured" };
  if (username.trim() !== ADMIN_USERNAME) return { ok: false, reason: "invalid" };
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(password));
  return toHex(digest) === ADMIN_PASSWORD_SHA256
    ? { ok: true, reason: null }
    : { ok: false, reason: "invalid" };
}
